const UserLayout = ({ children }) => {
  return (
    <div className="mt-[50px]">
      {children}
    </div>
  );
};

export default UserLayout;
